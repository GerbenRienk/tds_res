param([string[]]$ocextract)
$xslt = New-Object System.Xml.Xsl.XslCompiledTransform;
$xslt.Load("xml_convert_sas_map.xsl");
$xslt.Transform("$ocextract", "mapout_" + "$ocextract");
$xslt.Load("xml_convert_sas_data.xsl");
$xslt.Transform("$ocextract", "data_" + "$ocextract");
$xslt.Load("xml_convert_sas_format.xsl");
$xslt.Transform("$ocextract", "formatout_" + "$ocextract");