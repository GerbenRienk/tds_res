param([string[]]$ocextract, [string[]]$mapxsl, [string[]]$mapout, [string[]]$dataxsl, [string[]]$dataout)
$xslt = New-Object System.Xml.Xsl.XslCompiledTransform;
$xslt.Load("$mapxsl");
$xslt.Transform("$ocextract", "$mapout");
$xslt.Load("$dataxsl");
$xslt.Transform("$ocextract", "$dataout");
$xslt.Load("xml_convert_sas_format.xsl");
$xslt.Transform("$ocextract", "formatout_" + "$ocextract");